﻿using newshore.Models;
using System.Text.Json;

namespace newshore.Services
{
    public class FlightServices
    {
        public async Task<List<FlightResponse>> SearchFlights()
        {

            var httpClient = new HttpClient();

            string url = "https://recruiting-api.newshore.es/api/flights/2";


            var httpResponse = await httpClient.GetAsync(url);

            if (httpResponse.IsSuccessStatusCode)
            {
                var content = await httpResponse.Content.ReadAsStringAsync();
                List<FlightResponse> flights =
                    JsonSerializer.Deserialize<List<FlightResponse>>(content,
                    new JsonSerializerOptions()
                    {
                        PropertyNameCaseInsensitive = true
                    });
                return flights;
            }
            else
            {
                Console.WriteLine($"Error: {httpResponse.StatusCode}");
                return new List<FlightResponse>();
            }
        }
    }
}

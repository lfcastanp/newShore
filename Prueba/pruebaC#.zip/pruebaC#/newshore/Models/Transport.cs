﻿namespace newshore.Models
{
    public class Transport
    {
        public string? FlightCarrier {  get; set; }
        public string? FlightNumber {  get; set; }
    }
}

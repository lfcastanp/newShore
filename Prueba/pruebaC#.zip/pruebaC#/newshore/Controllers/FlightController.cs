﻿using Microsoft.AspNetCore.Mvc;
using newshore.Models;
using newshore.Services;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace newshore.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FlightController : ControllerBase
    {
        private List<Journey> journeys = new List<Journey>();

        [HttpGet]
        public async Task<ActionResult<List<Journey>>> Get()
        {
            var service = new FlightServices();
            var flights = await service.SearchFlights();

            string origin = HttpContext.Request.Query["origin"];
            string destination = HttpContext.Request.Query["destination"];

            SearchJourney(origin, destination, flights, new List<Flight>(),
                new List<string> { origin });

            return Ok(journeys);
        }

        private void SearchJourney(string origin, string destination,
    List<FlightResponse> flights, List<Flight> currentFlights, List<string> visitedCities)
        {
            if (origin == destination)
            {
                var journey = new Journey
                {
                    Flights = new List<Flight>(currentFlights),
                    Destination = destination,
                    Origin = currentFlights.First().Origin,
                    Price = currentFlights.Sum(f => f.Price ?? 0)
                };

                journeys.Add(journey);
            }
            else
            {
                var availableFlights = flights
                    .Where(f => f.DepartureStation == origin && !visitedCities.Contains(f.ArrivalStation))
                    .ToList();

                foreach (var flightResponse in availableFlights)
                {
                    var flight = new Flight
                    {
                        Transport = new Transport
                        {
                            FlightCarrier = flightResponse.FlightCarrier,
                            FlightNumber = flightResponse.FlightNumber
                        },
                        Destination = flightResponse.ArrivalStation,
                        Origin = flightResponse.DepartureStation,
                        Price = flightResponse.Price
                    };

                    visitedCities.Add(flightResponse.ArrivalStation);
                    currentFlights.Add(flight);

                    SearchJourney(flightResponse.ArrivalStation, destination, flights, currentFlights, visitedCities);

                    currentFlights.Remove(flight);
                    visitedCities.Remove(flightResponse.ArrivalStation);
                }
            }
        }

    }
}

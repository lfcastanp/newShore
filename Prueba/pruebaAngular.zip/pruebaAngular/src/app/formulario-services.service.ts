import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { JourneyModel } from '../models/journey.model';

@Injectable({
  providedIn: 'root'
})
export class FormularioServicesService {
  url: string = "http://localhost:5206/api/Flight"
  constructor(private http: HttpClient) { }

  SearchFlight(origin: string, destination: string): Observable<JourneyModel[]>{
    return this.http.get<JourneyModel[]>(`${this.url}?origin=${origin}&destination=${destination}`);
  }

  convertirMoneda(valor: number, monedaObjetivo: string): number {
    // Lógica para la conversión de moneda, puedes implementar la lógica según tus necesidades
    // Este es un ejemplo simple donde se asume que COP es el valor por defecto
    const tasaDeCambio: { [key: string]: number } = {
      'USD': 1,
      'EUR': 0.85,
      'COP': 3911
    };

    return valor * tasaDeCambio[monedaObjetivo];
  }
}

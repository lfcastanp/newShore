import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { log } from 'console';
import { FormularioServicesService } from '../formulario-services.service';
import { JourneyModel } from '../../models/journey.model';

@Component({
  selector: 'app-formulario',
  templateUrl: './formulario.component.html',
  styleUrls: ['./formulario.component.css'],
  providers: [FormularioServicesService]
})
export class FormularioComponent {
  formulario: FormGroup;
  fGroup: any;
  journeys: JourneyModel[] = [];
  monedaSeleccionada: string = 'USD';

  constructor(private formBuilder: FormBuilder, private servidor:FormularioServicesService) {
    this.formulario = this.formBuilder.group({
      origin: ['', Validators.required],
      destination: ['', [Validators.required]],
    });

  }

  enviarFormulario() {
    // Lógica para manejar el envío del formulario
    const origin = this.formulario.get("origin")?.value;
    const destination = this.formulario.get("destination")?.value;
    if(origin === destination){
      alert("Los campos no pueden contener el mismo valor.")
    }else{
      this.servidor.SearchFlight(origin, destination).subscribe({
        next: (data: any) => {
          this.journeys = data
          console.log(data)
        },
        error: (err) => {
          console.log(err)
        }
      })
    }
  }

  toUpperCase(controlName: string) {
    const control = this.formulario.get(controlName);
    if (control) {
      control.setValue(control.value.toUpperCase());
    }
  }

  // Función para convertir valores a la moneda seleccionada
  convertirMoneda(valor: number): number {
    return this.servidor.convertirMoneda(valor, this.monedaSeleccionada);
  }
}


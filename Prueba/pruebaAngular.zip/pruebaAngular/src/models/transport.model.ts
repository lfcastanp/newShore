export class TransportModel{
  flightCarrier?: string;
  flightNumber?: string;
}
